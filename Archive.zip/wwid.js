var currentJSONString = '{"TTInfoDictionary":{"TTInfo":[["eventID","32"],["userID","90000"],["documentDirectoryPath","file:///C:/Users/yuchang/Documents/92/"],["internetConnected","true"],["xdocVar","00"],["contentGroup","HO"],["business_unit","null"],["area","null"],["region","null"],["territory","null"],["groupID1","1"],["groupID2","1"],["groupID3","null"],["newFileUpdate","00"],["isMultiEvent","false"],["currentContentList","LTEN_Tabletop_App,FACILITATOR,Yu-Chang,Fu,0,null,null,null,null,MC3,HO,null,LTEN_Tabletop_App/content/resources_stresslax_pi.pdf,1"],["updateLater","false"]]}}'


